<?php include('../../includes/header.php'); ?>

<h1>Creating Orders</h1>

<div class="row">
You have two alternatives when Creating Orders. 

<ol>
<li>The createOrder() Method which returns the ID of the Order Created when successful</li>
<li>The SubmitOrder() Method which returns a detailed breakdown of the Order when successful</li>
</ol>

The sequence for pushing an order through the CCP system is as follows:

<ol>
<li></li>
</ol>

</div>

<div class="panel panel-default">
<div class="panel-heading"><a href="getAvailableProductOptions.php">getAvailableProductOptions()</a></div>
<div class="panel-body"><?php show_source('getAvailableProductOptions.php'); ?></div>
</div>

<div class="panel panel-default">
<div class="panel-heading"><a href="getOptionValues.php">getOptionValues()</a></div>
<?php show_source('getOptionValues.php'); ?>
</div>


<div class="panel panel-default">
<div class="panel-heading"><a href="getProductRanges.php">getProductRanges()</a></div>
<?php show_source('getProductRanges.php'); ?>
</div>


<div class="panel panel-default">
<div class="panel-heading"><a href="AddProduct.php">AddProduct()</a></div>
<?php show_source('AddProduct.php'); ?>
</div>


<?php include('../../includes/footer.php'); ?>